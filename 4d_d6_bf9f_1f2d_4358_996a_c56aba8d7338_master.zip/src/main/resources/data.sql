insert into user values(1,'tcs','fresco@gmail.com','fresco');
insert into user values(2,'tcs','wings@gmail.com','wings');
